<!DOCTYPE html>
<html>
  <head> 
    <base href="/public">

   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <style type="text/css">
  h1{
    text-align: center;
  }
   </style>
  </head>
  <body>
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">

            <div class="container">
                <h1>UPDATE BUS</h1>

                <form action="<?php echo e(url('edit_bus',$data->id)); ?>" method="Post" enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Bus Name</label>
                        <input type="text" name='title' value="<?php echo e($data->bus_title); ?>" class="form-control">
                      </div>
                    <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Origin</label>
                        <input type="text" name='depature' value="<?php echo e($data->start_From); ?>" class="form-control">
                        </div>
                      <div class="form-group col-md-6">
                        <label>Destination</label>
                        <input type="text" name='arrivals' value="<?php echo e($data->destination); ?>" class="form-control">
                      </div>
                      <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" name="description" cols="150" rows="3"><?php echo e($data->description); ?></textarea>
                      </div>
                    </div>
                    <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Bus Capacity</label>
                        <select name="type" class="form-control">
                            <option value="<?php echo e($data->bus_capacity); ?>"><?php echo e($data->bus_capacity); ?></option>
                            <option value="17">17 Seater</option>
                            <option value="29">29 Seater</option>
                            <option value="60">60 Seater</option>
                            <option value="Other">Other</option>
                        </select>
                        </div>
                      <div class="form-group col-md-2">
                        <label>Price</label>
                        <input type="number" name="price" value="<?php echo e($data->price); ?>"  class="form-control">
                      </div>
                      <div class="form-group col-md-3">
                        <label>Date</label>
                        <input type="date" name="bus_date" value="<?php echo e($data->bus_date); ?>"  class="form-control">
                      </div>
                      <div class="form-group col-md-3">
                        <label>Depature Time</label>
                        <input type="time" name="bus_time" value="<?php echo e($data->bus_time); ?>"  class="form-control">
                      </div>
                    </div>


                    <div class="form-row">
                        <div class="form-group col-md-2">
                            <label>Current Image</label>
                            <img src="/bus/<?php echo e($data->image); ?>" alt="" width="50px" height="50px">
                            </div>
                          <div class="form-group col-md-10">
                            <label>Upload Image</label>
                            <input type="file" name='image' class="form-control-file" >
                          </div>
                        </div>


                    









                        <input class="btn btn-outline-primary" type="submit" value="Add Bus">
                  </form>
                  



            </div>
          </div>
        </div>
      </div>

       <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\david.chamanga\code\bus_booking\resources\views/admin/update_bus.blade.php ENDPATH**/ ?>