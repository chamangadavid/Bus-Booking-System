<!DOCTYPE html>
<html>
  <head> 
    <base href="/public">
   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

  </head>
  <body>

    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">

       
                <h1>Mail send to <?php echo e($data->name); ?></h1>
           
            <form action="<?php echo e(url('mail',$data->id)); ?>" method="Post" class="form">

                <?php echo csrf_field(); ?>

                <div class="form-row">
                  <div class="form-group col-md-5">
                    <label for="inputEmail4">Greeting</label>
                    <input type="text" name="greeting" class="form-control" id="inputEmail4">
                  </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-5">
                      <label for="inputEmail4">Main Body</label>
                      <textarea class="form-control" name="body" id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                  </div>
                  
                    <div class="form-row">
                        <div class="form-group col-md-5">
                        <label>Action Text</label>
                        <input type="text" name="action_text" class="form-control" id="inputEmail4">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-5">
                        <label>Action Url</label>
                        <input type="text" name="action_url" class="form-control" id="inputEmail4">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-5">
                        <label>End Line</label>
                        <input type="text" name="endline" class="form-control" id="inputEmail4">
                        </div>
                    </div>
                    
                    <input type="submit" class="btn btn-outline-primary" value="Send mail"></input>
                </form>
            
          </div>
        </div>
      </div>
  
       <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\david.chamanga\code\bus_booking\resources\views/admin/send_mail.blade.php ENDPATH**/ ?>