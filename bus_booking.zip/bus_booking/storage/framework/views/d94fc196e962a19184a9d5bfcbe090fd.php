<!DOCTYPE html>
<html>
  <head> 
   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>

    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <table class="table table-hover table-dark">
                <thead>
                    <tr>
                        
                        <th scope="col">Firstname</th>
                        <th scope="col">Lastname</th>
                        <th scope="col">Email</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">Date</th>
                        <th scope="col">From</th>
                        <th scope="col">To</th>
                        <th scope="col">Bus</th>
                        <th scope="col">Price</th>
                        
                        
                        
                        
                        
                        <th scope="col">Status</th>
                        <th scope="col">Status update</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <td><?php echo e($item->firstname); ?></td>
                        <td><?php echo e($item->lastname); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->bookDate); ?></td>
                        <td><?php echo e($item->frombooking); ?></td>
                        <td><?php echo e($item->destination); ?></td>
                        <td>
                            <?php echo e($item->bus ? $item->bus->bus_title : 'No Bus Assigned'); ?>

                        </td>
                        <td>
                            K<?php echo e($item->bus ? $item->bus->price : 'N/A'); ?>

                        </td>

                        <td>
                            <?php if($item->status =='approved'): ?>
                                <span style="color: green;">Approved</span>

                                <?php endif; ?>

                                <?php if($item->status =='rejected'): ?>
                                <span style="color: red;">Rejected</span>

                                <?php endif; ?>

                                <?php if($item->status =='waiting'): ?>
                                <span style="color: yellow;">Waiting</span>

                                <?php endif; ?>
                        </td>
                        <td>
                           <span style="padding-right:5px;"> 
                            <a class="btn btn-outline-success" href="<?php echo e(url('approve_book',$item->id)); ?>">Approve</a></span>
                            <a class="btn btn-outline-warning" href="<?php echo e(url('reject_book',$item->id)); ?>">Reject</a>
                        </td>
                        <td>
                            <a onclick="return confirm('Are you sure you want to delete this?');" class="btn btn-outline-danger" href="<?php echo e(url('delete_booking',$item->id)); ?>">Del</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>
  
     
       <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\david.chamanga\code\bus_booking\resources\views/admin/booking.blade.php ENDPATH**/ ?>