<!DOCTYPE html>
<html>
  <head> 
   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </head>
  <body>

    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">

            <table class="table table-hover table-dark">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">From</th>
                        <th scope="col">To</th>
                        <th scope="col">Date</th>
                        <th scope="col">Time</th>
                        <th scope="col">Capacity</th>
                        <th scope="col">Price</th>
                        <th scope="col">Image</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->bus_title); ?></td>
                        <td><?php echo e($item->start_From); ?></td>
                        <td><?php echo e($item->destination); ?></td>
                        <td><?php echo e($item->bus_date); ?></td>
                        <td><?php echo e($item->bus_time); ?></td>
                        <td><?php echo e($item->bus_capacity); ?></td>
                        <td>K<?php echo e($item->price); ?></td>
                        <td>
                            <img src="bus/<?php echo e($item->image); ?>" alt="" width="30px" height="30px">
                        </td>
                        <td>
                            <a href="<?php echo e(url('bus_update', $item->id )); ?>" class="btn btn-outline-success">
                                Update
                            </a>
                            <a onclick="return confirm('Are you sure, you want to delete this record?')" href="<?php echo e(url('bus_delete', $item->id )); ?>" class="btn btn-outline-danger">
                                Delete
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
            <!-- Pagination Links -->
            <div class="d-flex justify-content-end">
                <?php echo $data->links(); ?>

            </div>
        </div>
      </div>
       <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\david.chamanga\code\bus_booking\resources\views/admin/view_bus.blade.php ENDPATH**/ ?>