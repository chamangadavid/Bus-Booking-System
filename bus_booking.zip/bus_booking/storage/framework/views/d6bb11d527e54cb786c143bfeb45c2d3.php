<?php echo e($slot); ?>

<?php /**PATH C:\Users\david.chamanga\code\bus_booking\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>