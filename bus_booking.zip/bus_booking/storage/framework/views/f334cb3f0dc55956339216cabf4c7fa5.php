<!DOCTYPE html>
<html>
  <head> 
   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>

    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">

      
                <h1>Gallery</h1>


            <form action="<?php echo e(url('upload_gallery')); ?>" method="Post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                  <label>Upload Image</label>
                  <input type="file" name="image" class="form-control-file" required>
                </div>

                <div>
                    <input type="submit" class="btn btn-outline-primary" value="Add Image"></input>
                </div>
              </form>
              <br><br>
              <div class="container">
              <div class="row">
                <?php $__currentLoopData = $gallary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallaries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="col-md-4">
                <img src="/gallary/<?php echo e($gallaries->image); ?>" alt="images">
                <a href="<?php echo e(url('delete_gallary',$gallaries->id)); ?>" class="btn btn-outline-danger">Delete Image</a>
              </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              </div>
          </div>
        </div>
      </div>

       <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\david.chamanga\code\bus_booking\resources\views/admin/gallary.blade.php ENDPATH**/ ?>