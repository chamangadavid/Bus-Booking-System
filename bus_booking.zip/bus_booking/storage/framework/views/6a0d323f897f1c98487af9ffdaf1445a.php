<!DOCTYPE html>
<html>
  <head> 
   <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>

    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <?php echo $__env->make('admin.body', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">

            <table class="table table-hover table-dark">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">Messages</th>
                        <th scope="col">Send Email</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td><?php echo e($item->phone); ?></td>
                        <td><?php echo e($item->message); ?></td>
                        <td>
                            <a class="btn btn-outline-success" href="<?php echo e(url('send_mail',$item->id)); ?>">Send mail</a>
                        </td>
                       
                        <td>
                            <a onclick="return confirm('Are you sure, you want to delete this record?')" href="<?php echo e(url('bus_delete', $item->id )); ?>" class="btn btn-outline-danger">
                                Delete
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

          </div>
        </div>
      </div>
  
       <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\Users\david.chamanga\code\bus_booking\resources\views/admin/all_messages.blade.php ENDPATH**/ ?>