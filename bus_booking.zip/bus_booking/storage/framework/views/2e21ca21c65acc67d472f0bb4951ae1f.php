<!DOCTYPE html>
<html lang="en">
   <head>
    <base href="/public">
    <?php echo $__env->make('home.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

   <!-- body -->
   <body class="main-layout">
      

      <header>
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </header>

      <div class="about">
        <div class="container-fluid">
           <div class="row">
              <div class="col-md-5">
                 <div class="titlepage">
                    <h2><?php echo e($bus->bus_title); ?></h2>
                    <p style="text-align: justify;"><?php echo e($bus->description); ?></p>
                    <table class="table table-hover">
                        <thead>
                          <tr>
                            <th scope="col">From</th>
                            <th scope="col">To</th>
                            <th scope="col">Date</th>
                            <th scope="col">Time</th>
                            <th scope="col">Price</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td><?php echo e($bus->start_From); ?></td>
                            <td><?php echo e($bus->destination); ?></td>
                            <td><?php echo e($bus->bus_date); ?></td>
                            <td><?php echo e($bus->bus_time); ?></td>
                            <th>K<?php echo e($bus->price); ?></th>
                          </tr>
                        </tbody>
                      </table>
                    <a href="<?php echo e(url('book_now', $bus->id)); ?>" class="btn btn-outline-primary"> Book Now</a>
                 </div>
              </div>
              <div class="col-md-7">
                 <div class="about_img">
                    <figure><img src="/bus/<?php echo e($bus->image); ?>" alt="bus details" style="height: 600px; width:600px"></figure>
                 </div>
              </div>
           </div>
        </div>
     </div>  
    <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html><?php /**PATH C:\Users\david.chamanga\code\bus_booking\resources\views/home/bus_details.blade.php ENDPATH**/ ?>