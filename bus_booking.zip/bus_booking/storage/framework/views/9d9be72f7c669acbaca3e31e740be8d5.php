<div class="about">
    <div class="container-fluid">
       <div class="row">
          <div class="col-md-5">
             <div class="titlepage">
                <h2>About Us</h2>
                <p style="text-align: justify">The Zambia Intercity Bus Terminal, often referred to simply as the Intercity Bus Terminal, is the main hub for long-distance bus travel in Lusaka, the capital city of Zambia. Located near the city center, this terminal is one of the busiest in the country and serves as a key point for travelers heading to various destinations within Zambia and to neighboring countries.</p>
                <h2>Key Features:</h2> 
                <ul>
                  <li>Location:</li>
                  <li>Bus Services:</li>
                  <li>Facilities:</li>
                  <li>Safety and Security:</li>
                </ul>
                
             </div>
          </div>
          <div class="col-md-7">
             <div class="about_img">
                <figure><img src="images/about.png" alt="#"/></figure>
             </div>
          </div>
       </div>
    </div>
 </div><?php /**PATH C:\Users\david.chamanga\code\bus_booking\resources\views/home/about.blade.php ENDPATH**/ ?>