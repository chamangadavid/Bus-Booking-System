<footer>
    <div class="footer">
       <div class="container">
          <div class="row">
             <div class=" col-md-4">
                <h3>Contact Info</h3>
                <ul class="conta">
                  <li>An intercity bus terminal is a structure where intercity buses stop to pick up and drop off passengers</li>
                  <ul class="conta">
                     <li><i class="fa fa-map-marker" aria-hidden="true"></i> Lusaka Inter City Bus Terminal</li>
                     
                  </ul>
                  
                </ul>
             </div>
             <div class="col-md-4">
               <h3>Location</h3>
               <ul class="conta">
                  <li><i class="fa fa-mobile" aria-hidden="true"></i> +260 979 760 679</li>
                  <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#"> intercity@gmail.com</a></li>
                  
               </ul>

             </div>
             <div class="col-md-4">
                <h3>Follow Us</h3>
               
        <ul class="conta">
                  <li> <i class="fa fa-mobile" aria-hidden="true"></i><a href="#"> 04:00 – 05:00    06:00 – 07:00 - MPOROKOSO </a></li>
                  <li><i class="fa fa-mobile" aria-hidden="true"></i> 04:00 – 05:00    04:00 – 05:00 - MWINILUNGA</li>
                  <li><i class="fa fa-mobile" aria-hidden="true"></i> 05:00 – 06:00    04:30 – 05:30 - KASAMA     </li>
               </ul>
             </div>
          </div>
       </div>
    </div>
 </footer>

 <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>